#!/bin/bash
vmLiveTyping-Stack/squeak CuisUniversity-5832.image