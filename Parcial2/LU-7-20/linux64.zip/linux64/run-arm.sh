#!/bin/bash
vmLiveTyping-ARM/squeak CuisUniversity-5832.image