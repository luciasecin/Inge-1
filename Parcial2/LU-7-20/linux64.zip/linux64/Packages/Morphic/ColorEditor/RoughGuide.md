Cuis-Smalltalk-ColorEditor
==========================
# Techniques of Interest

- Adds custom Morphs to the Morphic Menu (World Menu -> New Morph..)

- Making use of other packages (Requires Features CSS3-Colors and Morphic-Misc-1)

- Shows Feature "autoload" in code (method #ColorPallet>>useCrayonColorDict)

- Panel creation and usage

- Drag 'n Drop (DropTarget)

- Discussion of Color in Cuis (class comment in ColorPaneMorph)

- Uses Radio Buttons & Slider

- Shows model/view separation (#when:send:to:)

- Adds menu items to World Menu 

[ToDo -- add above examples & explain in Rough Guide to Cuis]
