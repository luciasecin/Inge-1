#!/bin/bash
vmLiveTyping/squeak CuisUniversity-5832.image