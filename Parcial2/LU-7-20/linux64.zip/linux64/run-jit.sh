#!/bin/bash
vm-jit/squeak CuisUniversity-5832.image